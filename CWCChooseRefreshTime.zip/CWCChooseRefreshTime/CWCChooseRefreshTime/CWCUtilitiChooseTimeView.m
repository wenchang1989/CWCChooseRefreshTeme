//
//  XFKFSUtilitiChooseTimeView.m
//  XF_XFT
//
//  Created by CWC on 17/8/15.
//  Copyright © 2017年 fang.com. All rights reserved.
//

#import "CWCUtilitiChooseTimeView.h"

#define CWC_COLOR(RED, GREEN, BLUE, ALPHA)	[UIColor colorWithRed:RED green:GREEN blue:BLUE alpha:ALPHA]
#define SCREENWIDTH [UIScreen mainScreen].bounds.size.width


@interface CWCUtilitiChooseTimeView ()<UIScrollViewDelegate>

/**
 *  选择时间视图
 */
@property (nonatomic, strong) UIScrollView *myScrollView;
/**
 *  时间数组
 */
@property (nonatomic, readwrite) NSMutableArray *timeDataArray;
@end

@implementation CWCUtilitiChooseTimeView


- (instancetype)initWithFrame:(CGRect)frame timeArray:(NSMutableArray *)timeArray{

    self = [super initWithFrame:frame];
    if (self) {
       
        [timeArray addObject:@"累计"];
        [timeArray addObject:@""];
        [timeArray insertObject:@"" atIndex:0];
        
        _timeDataArray = timeArray;
        self.backgroundColor = [UIColor clearColor];
        [self useTimeData];
        
    }
    
    return self;
}

- (UIColor *) colorWithHexString: (NSString *) stringToConvert
{
    NSString *cString = [[stringToConvert stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    
    // String should be 6 or 8 characters
    //if ([cString length] < 6) return DEFAULT_VOID_COLOR;
    
    // strip 0X if it appears
    if ([cString hasPrefix:@"0X"]) cString = [cString substringFromIndex:2];
    if ([cString hasPrefix:@"#"]) cString = [cString substringFromIndex:1];
    //if ([cString length] != 6) return DEFAULT_VOID_COLOR;
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    NSString *rString = [cString substringWithRange:range];
    
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    //SL_Log(@"%f:::%f:::%f",((float) r / 255.0f),((float) g / 255.0f),((float) b / 255.0f));
    
    return CWC_COLOR(((float) r / 255.0f),((float) g / 255.0f),((float) b / 255.0f), 1);
}


- (void)useTimeData{

    
    CGFloat width = (SCREENWIDTH-20)/3;
    self.backgroundColor = [self colorWithHexString:@"#0f1e41"];
    self.myScrollView.contentSize = CGSizeMake(self.timeDataArray.count*width, 40);
    
    NSInteger allItem = 0;
    
    NSString *blockTitle = @"all";
    
    if (self.timeDataArray.count >= 4) {
        allItem = self.timeDataArray.count-4;
    }
    
    self.myScrollView.contentOffset = CGPointMake(width*(allItem + 1), 0);
    blockTitle = @"all";
    
    if (self.didSelectTimeTitle) {
        self.didSelectTimeTitle(blockTitle);
    }
    
    for (int i = 0; i < self.timeDataArray.count; i++)
    {
        if (i == 0) {
            continue;
        }
        if (i == self.timeDataArray.count - 1) {
            continue;
        }
        UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(i*width, 0, width, 40)];
        
        [button setTitle:[self.timeDataArray objectAtIndex:i] forState:normal];
        
        
        
            if (i == self.timeDataArray.count - 2)
            {
                [button setTintColor:[UIColor whiteColor]];
            }
            else
            {
                [button setTitleColor:[self colorWithHexString:@"#235aba"] forState:normal];
            }
    
        button.backgroundColor = [UIColor clearColor];
        button.titleLabel.font = [UIFont systemFontOfSize:12];
        [button addTarget:self action:@selector(dateBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        button.tag = i+1000;
        [self.myScrollView addSubview:button];
        
    }
    
    [self addSubview:self.myScrollView];
    
    
    UIView *lineView  = [[UIView alloc]initWithFrame:CGRectMake(0, 40, SCREENWIDTH, 1)];
    lineView.backgroundColor = [self colorWithHexString:@"0c377f"];
    [self addSubview:lineView];

    
    UIImageView *arrowImageView = [[UIImageView alloc] init];
    [arrowImageView setFrame:CGRectMake((SCREENWIDTH-15)/2, 46, 15, 10)];
   
    [arrowImageView setImage:[UIImage imageNamed:@"customerArrow.png"]];
    [self addSubview:arrowImageView];
    
    
}

- (void)dateBtnClicked:(UIButton *)sender{

    NSInteger num = sender.tag - 1000;
    [UIView animateWithDuration:0.5 animations:^{
        self.myScrollView.contentOffset = CGPointMake((num - 1)*(SCREENWIDTH-20)/3, 0);
    }];
    for (id objc in self.myScrollView.subviews)
    {
        if ([objc isKindOfClass:[UIButton class]]) {
            UIButton *tempButton = objc;
            [tempButton setTitleColor:[self colorWithHexString:@"#235aba"] forState:normal];
        }
    }
    
    UIButton *button = (UIButton *)[self viewWithTag:sender.tag];
    
    [button setTitleColor:[UIColor whiteColor] forState:normal];
    
    NSString *blockTitle = @"all";
    
    if ([button.currentTitle isEqualToString:@"累计"])
    {
        
        
    }
    else if ([button.currentTitle isEqualToString:@""]) {
        
    }
    else
    {
        blockTitle = button.currentTitle;
    }
    if (![blockTitle isEqualToString:@""])
    {
        if (self.didSelectTimeTitle) {
            self.didSelectTimeTitle(blockTitle);
        }
        
    }

    
}

- (UIScrollView *)myScrollView{

    if (!_myScrollView) {
        _myScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(10, 0, SCREENWIDTH-20, 40)];
        _myScrollView.backgroundColor = [UIColor clearColor];
        _myScrollView.scrollEnabled = YES;
        _myScrollView.showsHorizontalScrollIndicator = NO;
        _myScrollView.delegate = self;
    }
    return _myScrollView;
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{

    CGFloat width = (SCREENWIDTH-20)/3;
    
    float contentOffset_X = roundf(scrollView.contentOffset.x / width);
    [scrollView setContentOffset:CGPointMake(contentOffset_X*width, 0) animated:NO];
    
    CGFloat getDateNumInt;
    
    getDateNumInt = contentOffset_X;
    NSInteger TAG = 1001;
        
        NSString *blockTitle = @"all";
        if ([[self.timeDataArray objectAtIndex:getDateNumInt+1] isEqualToString:@"累计"])
        {
            
        }
        else
        {
            blockTitle =[self.timeDataArray objectAtIndex:getDateNumInt+1];
            
        }
        
        if (self.didSelectTimeTitle) {
            self.didSelectTimeTitle(blockTitle);
        }
        
        for (id objc in self.myScrollView.subviews)
        {
            if ([objc isKindOfClass:[UIButton class]]) {
                UIButton *tempbutton = objc;
                [tempbutton setTitleColor:[self colorWithHexString:@"#235aba"] forState:normal];
            }
        }
        UIButton *button = (UIButton *)[self viewWithTag:getDateNumInt+TAG];
        [button setTitleColor:[UIColor whiteColor] forState:normal];

    
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{

    CGFloat width = (SCREENWIDTH-20)/3;
    
    float contentOffset_X = roundf(scrollView.contentOffset.x / width);
    [scrollView setContentOffset:CGPointMake(contentOffset_X*width, 0) animated:NO];
    
    CGFloat getDateNumInt;
    
    getDateNumInt = contentOffset_X;
    NSInteger TAG = 1001;
    if (!decelerate) {
        
        NSString *blockTitle = @"all";
        if ([[self.timeDataArray objectAtIndex:getDateNumInt+1] isEqualToString:@"累计"])
        {
            
        }
        else
        {
            blockTitle =[self.timeDataArray objectAtIndex:getDateNumInt+1];
            
        }
        
        if (self.didSelectTimeTitle) {
            self.didSelectTimeTitle(blockTitle);
        }
        
        for (id objc in self.myScrollView.subviews)
        {
            if ([objc isKindOfClass:[UIButton class]]) {
                UIButton *tempbutton = objc;
                [tempbutton setTitleColor:[self colorWithHexString:@"#235aba"] forState:normal];
            }
        }
        UIButton *button = (UIButton *)[self viewWithTag:getDateNumInt+TAG];
        [button setTitleColor:[UIColor whiteColor] forState:normal];
    }

    
    
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
