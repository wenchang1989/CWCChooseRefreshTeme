//
//  ViewController.m
//  CWCChooseRefreshTime
//
//  Created by CWC on 17/8/24.
//  Copyright © 2017年 CWC. All rights reserved.
//

#import "ViewController.h"
#import "CWCUtilitiChooseTimeView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor cyanColor];
    
    [self titleView];
    
    [self chooseTimeView];
    
    [self windowLabel];
}

- (UIStatusBarStyle)preferredStatusBarStyle{

    return UIStatusBarStyleLightContent;
    
}

- (void)windowLabel{

    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 50)];
    label.tag = 824;
    label.textAlignment = NSTextAlignmentCenter;
    label.backgroundColor = [UIColor clearColor];
    label.center = self.view.center;
    label.text = @"请选择时间";
    label.textColor = [UIColor blueColor];
    [self.view addSubview:label];
    
}


- (void)chooseTimeView{

    //默认选中最后一个
    CWCUtilitiChooseTimeView *timeView = [[CWCUtilitiChooseTimeView alloc] initWithFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.height-62, [UIScreen mainScreen].bounds.size.width, 62) timeArray:[@[@"2017-01",@"2017-02",@"2017-03",@"2017-04",@"2017-05",@"2017-06",@"2017-07",@"2017-08"] mutableCopy]];
    
    __weak __typeof(&*self)ws = self;
    
    timeView.didSelectTimeTitle=^(NSString *title){
    
        //此处处理选择时间后的操作
        
        UILabel *label = (UILabel *)[ws.view viewWithTag:824];
        
        label.text = [NSString stringWithFormat:@"您选择的时间是：%@",title];
    };
    
    [self.view addSubview:timeView];
}

- (void)titleView{

    UIView *titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 64)];
    titleView.backgroundColor = [UIColor blueColor];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 20, [UIScreen mainScreen].bounds.size.width, 44)];
    titleLabel.text = @"请选择时间";
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    [titleView addSubview:titleLabel];
    [self.view addSubview:titleView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
