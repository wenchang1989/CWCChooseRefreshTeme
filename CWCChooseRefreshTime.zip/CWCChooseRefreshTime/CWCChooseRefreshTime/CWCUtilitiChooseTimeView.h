//
//  XFKFSUtilitiChooseTimeView.h
//  XF_XFT
//
//  Created by CWC on 17/8/15.
//  Copyright © 2017年 CWC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CWCUtilitiChooseTimeView : UIView

/**
 *  时间数组
 */
@property (nonatomic, readonly) NSMutableArray *timeDataArray;
/**
 *  选择结束
 */
@property (nonatomic, strong) void(^didSelectTimeTitle)(NSString *selectTitle);
- (instancetype)initWithFrame:(CGRect)frame timeArray:(NSMutableArray *)timeArray;
@end
