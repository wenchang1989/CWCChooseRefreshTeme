//
//  AppDelegate.h
//  CWCChooseRefreshTime
//
//  Created by CWC on 17/8/24.
//  Copyright © 2017年 CWC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

